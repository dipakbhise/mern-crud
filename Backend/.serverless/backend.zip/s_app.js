
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dipakbhise',
  applicationName: 'backend',
  appUid: 'HYrQ6XzH77G4YDrJ6X',
  orgUid: 'ad30544d-0878-481d-98e3-acb39e528c03',
  deploymentUid: '55e446d6-65d6-44c7-99ad-dd45fb208f95',
  serviceName: 'backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'backend-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}